<template>
  <div class="about md:mt-10 mt-5 dark:text-gray-300">
    <h1 class="md:text-4xl text-3xl mb-3">Tentang</h1>

    <p class="italic">
      "Dan setiap umat mempunyai kiblat yang dia menghadap kepadanya. Maka
      berlomba-lombalah kamu dalam kebaikan. Di mana saja kamu berada, pasti
      Allah akan mengumpulkan kamu semuanya. Sungguh, Allah Mahakuasa atas
      segala sesuatu."
    </p>
    <p>-QS Al-Baqarah: 148</p>

    <div class="flex">
      <section class="icons mt-10 mr-12">
        <h2 class="md:text-2xl text-xl">Icons by</h2>
        <div>
          <ul class="list-disc text-indigo-200">
            <li class="ml-5">
              <a href="https://www.icons8.com/" target="_blank">Icons8</a>
            </li>
            <li class="ml-5 my-1">
              <a href="https://www.flaticon.com/" target="_blank">Flaticon</a>
            </li>
            <li class="ml-5">
              <a href="https://www.svgrepo.com/" target="_blank">SVGRepo</a>
            </li>
          </ul>
        </div>
      </section>

      <section class="data-api mt-10">
        <h2 class="md:text-2xl text-xl">API from</h2>
        <a href="https://github.com/sutanlab/quran-api" class="text-indigo-200"
          >Sutanlab Qur'an API</a
        >
      </section>
    </div>

    <the-footer class="fixed bottom-0 left-0 right-0 mb-24"></the-footer>
  </div>
</template>