<template>
    <div
      class="max-w-md mx-auto bg-white rounded-md shadow-lg overflow-hidden md:max-w-2xl mt-6 p-5 dark:bg-gray-800 dark:text-gray-300"
    >
        <slot></slot>
    </div>
</template>