<template>
    <div class="footer text-center pt-6 dark:text-gray-200">
        <p>Made with ❤️ by <a href="https://web.facebook.com/rangga.dimas80/" class="text-indigo-300" target="_blank">Rangga Dimas</a></p>
    </div>
</template>