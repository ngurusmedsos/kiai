<template>
    <div
      class="sucess-modal px-4 py-3 text-sm md:text-base z-50 font-semibold fixed bottom-0 md:mb-24 mb-20 bg-green-400 dark:bg-green-500 rounded-md shadow-lg text-white"
    >
      <slot></slot>
    </div>
</template>